An API Boilerplate for Node.js, Express.js & PostgresSQL for RAML-to-POSTMAN-Collection

Here's few of the challenges we faced while working on an enterprise applications;

FUNCTIONAL - (RAML-to-POSTMAN-Collection)
1. SWAGGER to OPEN-API Specification conversion
2. OPEN-API or SWAGGER to RAML Specification Conversion
3. OPEN-API or SWAGGER or RAML to POSTMAN-Collection Conversion 

We came up with express-typescript-postgress, this repository solves all the above mentioned problems as well as the things beyond that! Here's the list of few things we've accomplished;

FUNCTIONAL - (RAML-to-POSTMAN-Collection)
1. SWAGGER to OPEN-API Specification conversion and vice-versa with configurable project attribute
2. OPEN-API or SWAGGER to RAML Specification Conversion and vice-versa with configurable project attribute
3. OPEN-API or SWAGGER or RAML to POSTMAN-Collection Conversion and vice-versa with configurable project attribute
4. SIMPLE and ELEGANT UI to support API Specification Conversion
5. Adding Test Scenarios + Test Data, if required

and many more...

# What are the Pre-requisites?

Binaries      | Version
------------- | -------------
NodeJS        		| >= LTS
NPM           		| >= 8.19.2
ts-node-dev   		| >= 2.0.0
VSCode		  		| >=1.79.0

# Download Link for Pre-requisites

NodeJS           	| https://nodejs.org/dist/v18.16.1/node-v18.16.1-win-x64.zip
VSCode		  		| https://code.visualstudio.com/Download#

# How to SetUp & Install?

```sh
# Clone the repository "https://github.com/mulesoftcoe/services-raml-to-postman-collection"
git clone 

# Install NPM dependencies
npm install;

# In case of any problem or issue, use below command:
npm cache clear --force
npm install

# How to Run?

### Development Environment

```sh
cd src/
npm run dev;
```

# API Available
URL: http://`<HOST>:<PORT>`/raml-to-postman-collection/from/raml/content/upload
Purpose: To UPLOAD a single file <file-name>.raml with POST request and run the API to see the result

URL: http://`<HOST>:<PORT>`/raml-to-postman-collection/from/raml/zip/upload
Purpose: To UPLOAD a single compressed file <file-name>.zip with POST request and run the API to see the result

# How to access the API Documentation?

- Try accessing the http://`<HOST>:<PORT>`/swagger
- Note: Remember to replace the "HOST" & "IP" with your HOST & PORT number.
