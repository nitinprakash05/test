const express = require("express");
const router = express.Router();
const controller = require("../controller/file.controller");

let routes = (app) => {
  router.post("/", controller.api_get);
  router.post("/raml-to-postman-collection/from/raml/content/upload", controller.upload);
  router.post("/raml-to-postman-collection/from/raml/zip/upload", controller.zip_upload);
  // router.get("/files", controller.getListFiles);
  // router.get("/files/:name", controller.download);
  // router.delete("/files/:name", controller.remove);

  app.use(router);
};

module.exports = routes;
