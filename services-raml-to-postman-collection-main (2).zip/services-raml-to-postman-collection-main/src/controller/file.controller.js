const uploadFile = require("../middleware/upload");
const fs = require("fs");
const yaml = require('js-yaml');
const baseUrl = "http://localhost:8080/files/";
const attrib_name = "employeeName";
const attrib_val = "Sample Name";

const api_get = async (req, res) => {
  try {
    return res.status(200).send({ message: "PUBLIC AP!" });
  } catch (err) {
      console.log(err);
      return res.status(500).send({
      message: "SOMETHING HAPPENED TO SERVER, CHECK LOGS!",
      });
  }   
};  

const upload = async (req, res) => {
  try {
    await uploadFile(req, res);

    if (req.file == undefined) {
      return res.status(400).send({ message: "Please upload a file!" });
    } else {

      var fs = require('fs');
      const directoryPath = __basedir + "/resources/static/assets/uploads/";
      const fileName = req.file.originalname;
      Converter = require('raml1-to-postman'),
      ramlSpec = fs.readFileSync(directoryPath + fileName, {encoding: 'UTF8'});

      Converter.convert({ type: 'string', data: ramlSpec },
        {}, (err, conversionResult) => {
        if (!conversionResult.result) {
          console.log('Could not convert', conversionResult.reason);
          res.status(400).send({ message: {'Could not convert': conversionResult.reason}});
          // res.send({'Could not convert': conversionResult.reason});
        }
        else {
          console.log('The collection object is: ', conversionResult.output[0].data);
          res.status(200).send(conversionResult.output[0].data);
          // res.send(conversionResult.output[0].data);
        }
      }
      );
      res.status(200).send({
        message: "Uploaded the file successfully: " + req.file.originalname,
      });
    }  
  } catch (err) {
    console.log(err);

    if (err.code == "LIMIT_FILE_SIZE") {
      return res.status(500).send({
        message: "File size cannot be larger than 2MB!",
      });
    }

    res.status(500).send({
      message: `Could not upload the file: ${req.file.originalname}. ${err}`,
    });
  }
};

function guid() {
  var s4 = () => Math.floor((1 + Math.random()) * 0x10000)
      .toString(16)
      .substring(1);
  return s4() + s4() + '-' + s4() + '-' + s4() + '-' +
      s4() + '-' + s4() + s4() + s4();
}

function generate_id(maxFieldsCount) {
  var count = Math.floor(Math.random() * (maxFieldsCount + 1));
  for (var i = 0; i < count; i++) {
      this[guid()] = guid();
  }

  return guid()
}


const zip_upload = async (req, res) => {
  try {
    await uploadFile(req, res);

    if (req.file == undefined) {
      return res.status(400).send({ message: "Please upload a file!" });
    } else {
      const decompress = require("decompress");
      var fs = require('fs');
      const directoryPath = __basedir + "/resources/static/assets/uploads/";
      // console.log(req.body);
      // console.log(req.files);
      const fileName = req.file.originalname.toString().split(".")[0];
      const decompressing_directory = directoryPath + fileName + "_dist";
      const raml_file_name_for_conversion = directoryPath + fileName + "_dist/" + fileName + ".raml";
      
      // console.log(decompressing_directory);
      // console.log(raml_file_name_for_conversion);

      decompress(directoryPath + req.file.originalname, directoryPath + fileName + "_dist")
      .then((files) => {
        // console.log(files);
      })
      .catch((error) => {
        console.log(error);
      });

      Converter = require('raml1-to-postman'),
      ramlSpec = fs.readFileSync(raml_file_name_for_conversion, {encoding: 'UTF8'});

      // YAML/RAML to JSON COnversion
      // const obj = yaml.load(fs.readFileSync(raml_file_name_for_conversion, {encoding: 'utf-8'})); 
      // console.log(JSON.stringify(obj, null, 2))
      // fs.writeFileSync(outputJSON, JSON.stringify(obj, null, 2));

      Converter.convert({ type: 'string', data: ramlSpec, options:  {
                                                                      collapseFolders: true,
                                                                      requestParametersResolution: 'example',
                                                                      exampleParametersResolution: 'example'
                                                                    }
                      /*
                      All three properties are optional. Defaults will be used for no options provided. Check the options section below for possible values for each option..
                      */}, 
        {}, (err, conversionResult) => {
        if (!conversionResult.result) {
          console.log('Could not convert', conversionResult.reason);
          res.status(400).send({ message: {'Could not convert': conversionResult.reason}});
          // res.send({'Could not convert': conversionResult.reason});
        }
        else {
          var returned_data = conversionResult.output[0].data
          // returned_data_object = JSON.parse(returned_data)
          for (var key in returned_data.item[1].item)
            if (returned_data.item[1].item[key].request.method == "POST")
              // console.log(returned_data.item[1].item[key])
              var name_of_endpoint = returned_data.item[1].item[key].name.replace('/', '')
              // name_of_endpoint = name_of_endpoint.replace('/', '')
              
              // FOR - POSITIVE ENDPOINT - DEFAULT
              // var name_of_endpoint_default = 'POST ' + name_of_endpoint + ' URI - DEFAULT' 
              // returned_data.item[1].item[key].name = name_of_endpoint_default
              // returned_data.item[1].item[key].request.body[attrib_name] = attrib_val

              var return_data_response = returned_data.item[1].item[key]
              returned_data.item[1].item = []

              var return_data_response_DEFAULT = return_data_response
              var name_of_endpoint_response_DEFAULT = 'POST ' + name_of_endpoint + ' URI - DEFAULT' 
              var new_id_value = generate_id(36)
              
              return_data_response_DEFAULT.id = new_id_value
              return_data_response_DEFAULT.name = name_of_endpoint_response_DEFAULT
              return_data_response_DEFAULT.request.body[attrib_name] = attrib_val
              // console.log(return_data_response_DEFAULT)
              console.log(returned_data.item[1].item)

              returned_data.item[1].item.push(return_data_response_DEFAULT)
              // console.log(returned_data.item[1].item)


              // FOR - POSITIVE ENDPOINT - RESPONSE CODE - 200
              raw_url = name_of_endpoint
              var return_data_response_200 = {
                id: generate_id(36),
                response: [],
                event: [],
                name: 'POST ' + name_of_endpoint + ' URI - RESPONSE-200',
                request: {
                  url: {
                      path: [
                        name_of_endpoint
                      ],
                      raw: "{{baseUrl}}/" + raw_url,
                      host: [
                          "{{baseUrl}}"
                      ],
                      query: [],
                      variables: []
                  },
                  method: "POST",
                  header: [
                    {
                      key: "Content-Type",
                      type: "text",
                      value: "application/json"
                    }
                  ],
                  body: {
                    mode: "raw",
                    raw: {
                      [attrib_name]: attrib_val,
                      
                    }
                  }
              }
              }
              returned_data.item[1].item.push(return_data_response_200)

              // FOR - POSITIVE ENDPOINT - RESPONSE CODE - 400
              raw_url = name_of_endpoint
              var return_data_response_400 = {
                id: generate_id(36),
                response: [],
                event: [],
                name: 'POST ' + name_of_endpoint + ' URI - RESPONSE-400',
                request: {
                  url: {
                      path: [
                        name_of_endpoint
                      ],
                      raw: "{{baseUrl}}/" + raw_url,
                      host: [
                          "{{baseUrl}}"
                      ],
                      query: [],
                      variables: []
                  },
                  method: "POST",
                  header: [
                    {
                      key: "Content-Type",
                      type: "text",
                      value: "application/json"
                    }
                  ],
                  body: {
                    mode: "raw",
                    raw: {
                      [attrib_name]: "",
                      sample: "some sample"
                    }
                  }
              }
              }
              returned_data.item[1].item.push(return_data_response_400)

              // FOR - POSITIVE ENDPOINT - RESPONSE CODE - 404
              raw_url = name_of_endpoint + "_not_found"
              var return_data_response_404 = {
                id: generate_id(36),
                response: [],
                event: [],
                name: 'POST ' + name_of_endpoint + ' URI - RESPONSE-404',
                request: {
                  url: {
                      path: [
                        raw_url
                      ],
                      raw: "{{baseUrl}}/" + raw_url,
                      host: [
                          "{{baseUrl}}"
                      ],
                      query: [],
                      variables: []
                  },
                  method: "POST",
                  header: [
                    {
                      key: "Content-Type",
                      type: "text",
                      value: "application/json"
                    }
                  ],
                  body: {
                    mode: "raw",
                    raw: {
                      [attrib_name]: "",
                      sample: "some sample"
                    }
                  }
              }
              }
              returned_data.item[1].item.push(return_data_response_404)

            
            collection_info = {
              info: {
                _postman_id: generate_id(36),
                name: "ntt-raml-template",
                description: "# Description\n\nThis is NTT template for RAMl specification with all the best practices and standards. Please use it and make changes as per the requirements.\n\n# Documentation\n\nInvalid Documentaion key-value pair\n",
                schema: "https://schema.getpostman.com/json/collection/v2.1.0/collection.json"
              }
            }
            
            returned_data.info = collection_info.info

            res.status(200).send(returned_data);
        }
      }
      );
      
      // res.status(200).send({
      //   message: "Uploaded the file successfully: " + req.file.originalname,
      // });
    }  
  } catch (err) {
    console.log(err);

    if (err.code == "LIMIT_FILE_SIZE") {
      return res.status(500).send({
        message: "File size cannot be larger than 2MB!",
      });
    }

    res.status(500).send({
      message: `Could not upload the file: ${req.file.originalname}. ${err}`,
    });
  }
};





const getListFiles = (req, res) => {
  const directoryPath = __basedir + "/resources/static/assets/uploads/";

  fs.readdir(directoryPath, function (err, files) {
    if (err) {
      res.status(500).send({
        message: "Unable to scan files!",
      });
    }

    let fileInfos = [];

    files.forEach((file) => {
      fileInfos.push({
        name: file,
        url: baseUrl + file,
      });
    });

    res.status(200).send(fileInfos);
  });
};

const download = (req, res) => {
  const fileName = req.params.name;
  const directoryPath = __basedir + "/resources/static/assets/uploads/";

  res.download(directoryPath + fileName, fileName, (err) => {
    if (err) {
      res.status(500).send({
        message: "Could not download the file. " + err,
      });
    }
  });
};

const remove = (req, res) => {
  const fileName = req.params.name;
  const directoryPath = __basedir + "/resources/static/assets/uploads/";

  fs.unlink(directoryPath + fileName, (err) => {
    if (err) {
      res.status(500).send({
        message: "Could not delete the file. " + err,
      });
    }

    res.status(200).send({
      message: "File is deleted.",
    });
  });
};

const removeSync = (req, res) => {
  const fileName = req.params.name;
  const directoryPath = __basedir + "/resources/static/assets/uploads/";

  try {
    fs.unlinkSync(directoryPath + fileName);

    res.status(200).send({
      message: "File is deleted.",
    });
  } catch (err) {
    res.status(500).send({
      message: "Could not delete the file. " + err,
    });
  }
};

module.exports = {
  upload,
  api_get,
  upload,
  zip_upload,
  getListFiles,
  download,
  remove,
  removeSync,
};
